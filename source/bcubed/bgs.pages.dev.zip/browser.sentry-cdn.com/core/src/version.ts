export const SDK_VERSION = '6.2.2';
