/**
 * Minified by jsDelivr using Terser v5.17.1.
 * Original file: /npm/@widgetbot/crate@3.5.5/umd/crate.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
